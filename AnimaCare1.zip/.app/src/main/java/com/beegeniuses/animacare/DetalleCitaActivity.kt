package com.beegeniuses.animacare

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.beegeniuses.animacare.databinding.ActivityDetallecitaBinding
import com.google.firebase.Timestamp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.type.DateTime
import java.util.*

class DetalleCitaActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetallecitaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetallecitaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.etDate.setOnClickListener{
            showDatePickerDialog()
        }

        val db = Firebase.firestore
        val user = Firebase.auth.currentUser

        val uid = user?.uid

        binding.btnRegCita.setOnClickListener{

            val fecha = binding.etDate.text.toString()
            val citiesRef = db.collection("citas")

            var salida = ""
            var horario1 = false
            var horario2 = false
            var horario3 = false
            var horario4 = false

            citiesRef.whereEqualTo("fecha", fecha)//.whereEqualTo("horario", horario)
                .get()
                .addOnSuccessListener { documents ->
                    for (document in documents) {
                        if (document.data?.get("horario") == "12:30" ){
                            salida = salida + "El horario de 12:30 ya esta ocupado \n"
                            horario1 = true
                        } else if (document.data?.get("horario") == "2:30"){
                            salida = salida +"El horario de 2:30 ya esta ocupado \n"
                            horario2 = true
                        } else if (document.data?.get("horario") == "4:30"){
                            salida = salida + "El horario de 4:30 ya esta ocupado \n"
                            horario3 = true
                        } else if (document.data?.get("horario") == "6:30"){
                            salida = salida + "El horario de 6:30 ya esta ocupado \n"
                            horario4 = true
                        }
                    }

                    if (horario1 == true){
                        binding.horario1.setEnabled(false)
                        binding.horario1.setChecked(false)
                    }
                    if (horario2 == true){
                        binding.horario2.setEnabled(false)
                        binding.horario2.setChecked(false)
                    }
                    if (horario3 == true){
                        binding.horario3.setEnabled(false)
                        binding.horario3.setChecked(false)
                    }
                    if (horario4 == true){
                        binding.horario4.setEnabled(false)
                        binding.horario4.setChecked(false)
                    }

                    binding.txtSalidaCitas.text = salida

                    binding.btnEnviarCita.visibility = View.VISIBLE
                    binding.btnRegCita.setEnabled(false)

                    if (horario1 == true && horario2 == true
                        && horario3 == true && horario4 == true){
                        binding.horario1.setEnabled(true)
                        binding.horario2.setEnabled(true)
                        binding.horario3.setEnabled(true)
                        binding.horario4.setEnabled(true)

                        binding.horario1.setChecked(false)
                        binding.horario2.setChecked(false)
                        binding.horario3.setChecked(false)
                        binding.horario4.setChecked(false)
                        salida = "Este día no esta disponible"

                        binding.txtSalidaCitas.text = salida

                        binding.btnEnviarCita.visibility = View.INVISIBLE
                        binding.btnRegCita.setEnabled(true)
                    }
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(baseContext, "Error.",
                        Toast.LENGTH_SHORT).show()
                }
        }

        binding.btnEnviarCita.setOnClickListener{
            val fecha = binding.etDate.text.toString()
            var horario = ""

            if(binding.horario1.isChecked == true) {
                horario = "12:30"
            } else if(binding.horario2.isChecked == true){
                horario = "2:30"
            } else if(binding.horario3.isChecked == true){
                horario = "4:30"
            } else if(binding.horario4.isChecked == true){
                horario = "6:30"
            }

            if (horario.isEmpty()){
                Toast.makeText(baseContext, "No tienes horario marcado.",
                    Toast.LENGTH_SHORT).show()
            } else {
                val cita = hashMapOf(
                    //"fecha" to Timestamp(Date(fecha)),
                    "fecha" to fecha,
                    "horario" to horario,
                    "status" to "pendiente")
                db.collection("citas").document(uid.toString()).set(cita)
                regMain()
            }
        }
    }

    private fun showDatePickerDialog() {
        val dataPicker = DataPickerFragment{day, month, year -> onDateSelected(day, month, year)}
        dataPicker.show(supportFragmentManager, "datePicker")
    }

    fun onDateSelected(day:Int, month:Int, year:Int){
        binding.etDate.setText("$day/$month/$year")
    }

    private fun regMain(){
        val intent = Intent(this, MainActivity::class.java)
        this.startActivity(intent)
    }
}