package com.beegeniuses.animacare

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.beegeniuses.animacare.databinding.ActivityDetallemascotaBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class DetalleMascotaActivity: AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityDetallemascotaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetallemascotaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val dato =  intent.getStringExtra("dato_mascota").toString()

        val db = Firebase.firestore

        db.collection("mascotas").document(dato)
            .get()
            .addOnSuccessListener { document ->
                val nombre = document.data?.get("nombre").toString()
                val raza = document.data?.get("raza").toString()
                val valSexo = document.data?.get("sexo")
                val edad = document.data?.get("edad").toString()

                if (valSexo == "macho"){
                    binding.radioMacho.setChecked(true)
                } else {
                    binding.radioHembra.setChecked(true)
                }

                binding.etxtActNombre.setText(nombre)
                binding.etxtActRaza.setText(raza)
                binding.etxtEdadMascota.setText(edad)

            }
            .addOnFailureListener { exception ->
                Toast.makeText(baseContext, "Ha ocurrido un Error: "+ exception,
                    Toast.LENGTH_SHORT).show()
            }

        binding.btnActualizarMascota.setOnClickListener{
            var sexo: String = "hembra"
            if (binding.radioMacho.isChecked === true)sexo = "macho"
            val nombre = binding.etxtActNombre.text.toString()
            val raza = binding.etxtActRaza.text.toString()
            val edad = binding.etxtEdadMascota.text.toString()

            val update = hashMapOf(
                "nombre" to nombre,
                "raza" to raza,
                "sexo" to sexo,
                "edad" to edad,)

            if(nombre.isEmpty()) {
                Toast.makeText(
                    baseContext, "Ingresa un nombre valido.",
                    Toast.LENGTH_SHORT).show()
            } else if(raza.isEmpty()){
                Toast.makeText(baseContext, "Ingresa una raza valida.",
                    Toast.LENGTH_SHORT).show()
            } else if(edad.isEmpty()){
                Toast.makeText(baseContext, "Ingresa una edad valida.",
                    Toast.LENGTH_SHORT).show()
            } else {
                db.collection("mascotas").document(dato)
                    .update(update as Map<String, Any>)

                regMain()
            }
        }

        binding.btnEliminarMascota.setOnClickListener{
            db.collection("mascotas").document(dato)
                .delete()

            regMain()
        }

    }

    private fun regMain(){
        val intent = Intent(this, MainActivity::class.java)
        this.startActivity(intent)
    }
}