package com.beegeniuses.animacare

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.beegeniuses.animacare.databinding.ActivityExpedienteBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class ExpedienteActivity : AppCompatActivity() {
    private lateinit var binding: ActivityExpedienteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityExpedienteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val dato =  intent.getStringExtra("dato_mascota").toString()

        val db = Firebase.firestore


    }


}