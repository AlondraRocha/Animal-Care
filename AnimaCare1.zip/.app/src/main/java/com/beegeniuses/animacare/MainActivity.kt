package com.beegeniuses.animacare

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.beegeniuses.animacare.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = Firebase.auth
        val db = Firebase.firestore

        val user = Firebase.auth.currentUser

        val uid = user?.uid

        var datos = ""


        db.collection("citas").document(uid.toString())
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()){
                    Toast.makeText(baseContext, "Tienes una cita en espera ",
                        Toast.LENGTH_SHORT).show()
                } else {
                    binding.btnSolicitarCita.visibility = View.VISIBLE
                }
            }
            .addOnFailureListener{ e ->
                Toast.makeText(baseContext, "Error al cargar."+ e,
                    Toast.LENGTH_SHORT).show()
            }

        db.collection("mascotas")
            .whereEqualTo("dueño", uid)
            .get()
            .addOnSuccessListener { documents ->
                    for (document in documents) {
                        datos = "\n" + "Nombre: "+document.data.get("nombre") + "\n" + "Raza: "+document.data.get("raza") + "\n" + "Sexo: "+document.data.get("sexo") + "\n" + "Edad: "+document.data.get("edad") + "\n"
                        val textLista = TextView(this)
                        //val textButton = Button(this)
                        //textButton.text = "Ver Expediente"
                        val identificador_mascota = document.id
                        textLista.textSize = 20f
                        textLista.text = datos
                        textLista.setOnClickListener{editarMascota(identificador_mascota)}
                        //textButton.setOnClickListener{crearExpediente(identificador_mascota)}
                        binding.clVistaMain.addView(textLista)
                        //binding.clVistaMain.addView(textButton)
                    }
                }
            .addOnFailureListener { exception ->
                Toast.makeText(baseContext, "Error al cargar.",
                    Toast.LENGTH_SHORT).show()
            }



        binding.btnCerrarSesion.setOnClickListener{
            auth.signOut()
            reload()
        }

        binding.btnRegisMascota.setOnClickListener{
            reRegisMascota()
        }

        binding.btnSolicitarCita.setOnClickListener{
            cita()
        }

    }

    private fun reload(){
        val intent = Intent(this, SingInActivity::class.java)
        this.startActivity(intent)
    }
    private fun reRegisMascota(){
        val intent = Intent(this, RegMascotaActivity::class.java)
        this.startActivity(intent)
    }
    private fun editarMascota(dato: String){
        val intent = Intent(this, DetalleMascotaActivity::class.java)
        intent.putExtra("dato_mascota", dato)
        this.startActivity(intent)
    }
    private fun crearExpediente(dato: String){
        val intent = Intent(this, ExpedienteActivity::class.java)
        intent.putExtra("dato_mascota", dato)
        this.startActivity(intent)
    }

    private fun cita(){
        val intent = Intent(this, DetalleCitaActivity::class.java)
        this.startActivity(intent)
    }
}