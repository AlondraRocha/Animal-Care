package com.beegeniuses.animacare

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import com.beegeniuses.animacare.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import java.util.regex.Pattern

class RegisterActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityRegisterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = Firebase.auth

        binding.btnRegistrarse.setOnClickListener{
            val vEmail = binding.txtCorreo.text.toString()
            val vPass = binding.txtPassword.text.toString()
            val vConPass = binding.txtConfPass.text.toString()
            val passwordRegex = Pattern.compile("^" +
                    "(?=.*[-@#$%^&+=])"+
                    ".{2,}"+
                    "$")
            if (vEmail.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(vEmail).matches()){
                Toast.makeText(baseContext, "Ingresa un Correo valido.",
                    Toast.LENGTH_SHORT).show()
            } else if (vPass.isEmpty() || !passwordRegex.matcher(vPass).matches()){
                Toast.makeText(baseContext, "La contraseña es débil.",
                    Toast.LENGTH_SHORT).show()
            } else if (vPass != vConPass){
                Toast.makeText(baseContext, "Las contraseñas deben ser las mismas.",
                    Toast.LENGTH_SHORT).show()
            } else {
                crearCuenta(vEmail, vPass)
            }
        }
    }

    private fun crearCuenta(email : String, password : String){
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    reload()
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w("TAG", "createUserWithEmail:failure", task.exception)
                    Toast.makeText(baseContext, "Autentificación Fallida.",
                        Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun reload(){
        val intent = Intent(this, SingInActivity::class.java)
        startActivity(intent)
    }


}