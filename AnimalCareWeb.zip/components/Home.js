import React, { useState, useEffect } from "react"
import firebaseApp from "../credenciales";
import { getAuth, signOut } from "firebase/auth";
import { getDoc, getFirestore, collection, query, where, getDocs, doc, addDoc, deleteDoc, setDoc } from "firebase/firestore";
import { async } from "@firebase/util";

const auth = getAuth(firebaseApp);
const firestore = getFirestore(firebaseApp);

export const Home = ({ llaveUsuario }) => {

    const valorInicial = {
        nombre: '',
        raza: '',
        sexo: '',
        edad: ''
    }

    const [mascota, setMascota] = useState(valorInicial);
    const [data, setData] = useState([]);
    const [subId, setSubId] = useState('');
    const [citas, setCitas] = useState([]);

    const capturarInputs = (e) => {
        const { name, value } = e.target;
        setMascota({ ...mascota, [name]: value });
    }

    //actualziar datos

    const guardarDatos = async (e) => {
        e.preventDefault();
        await setDoc(doc(firestore, "mascotas", subId), {
            ...mascota
        });
        setMascota({ ...valorInicial });
        setSubId('');
    }

    useEffect(() => {
        const getLista = async () => {
            try {
                const citiesRef = collection(firestore, "mascotas");
                //const q = query(citiesRef, where("dueño", "==", llaveUsuario));
                const querySnapshot = await getDocs(citiesRef);
                const docs = []
                querySnapshot.forEach((doc) => {
                    docs.push({ ...doc.data(), id: doc.id });
                });
                setData(docs);
            } catch (error) {
                console.log(error)
            }
        }
        getLista();
    }, [data]);

    useEffect(() => {
        const getCitas = async () => {
            try {
                const citiesRef = collection(firestore, "citas");
                const querySnapshot = await getDocs(citiesRef);
                const docs = []
                querySnapshot.forEach((doc) => {
                    docs.push({ ...doc.data(), id: doc.id });
                });
                setCitas(docs);
            } catch (error) {
                console.log(error)
            }
        }
        getCitas();
    }, [citas]);

    const deleteUser = async (id) => {
        await deleteDoc(doc(firestore, "mascotas", id));
    }

    const getOne = async (id) => {
        try {
            const docRef = doc(firestore, "mascotas", id);
            const docSnap = await getDoc(docRef)
            setMascota(docSnap.data())
        } catch (error) {
            console.log(error);
        }
    }

    useEffect(() => {
        if (subId !== '') {
            getOne(subId)
        }
    }, [subId])

    const deleteCita = async (id) => {
        await deleteDoc(doc(firestore, "citas", id));
    }

    return (
        <div className="container">
            <h1>Bienvenido Haz iniciado sesión</h1>
            <button className="btn btn-success" onClick={() => signOut(auth)}>Cerrar Sesión</button>
            <hr />
            <div className="row">
                <form className="form-control" id="form1" onSubmit={guardarDatos}>
                    <h4>Registra una nueva mascota</h4>
                    <div className="mb-3">
                        <input type="text" className="form-control" name="nombre" placeholder="Nombre de la Mascota"
                            onChange={capturarInputs} value={mascota.nombre} />
                    </div>
                    <div className="mb-3">
                        <input type="text" className="form-control" name="raza" placeholder="Raza"
                            onChange={capturarInputs} value={mascota.raza} />
                    </div>
                    <div className="mb-3">
                        <input type="text" className="form-control" name="sexo" placeholder="macho o hembra"
                            onChange={capturarInputs} value={mascota.sexo} />
                    </div>
                    <div className="mb-3">
                        <input type="number" className="form-control" name="edad" placeholder="Edad"
                            onChange={capturarInputs} value={mascota.edad} />
                    </div>
                    <div className="mb-3">
                        <button className="btn btn-warning">Actualizar</button>
                    </div>
                </form>
            </div>

            <div className="row">
                <table className="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Tus Mascotas</th>
                            <th>Accriones</th>
                        </tr>
                    </thead>
                    <tbody>                          {
                        data.map((mascota) => {
                            return (
                                <>
                                    <tr>
                                        <td>Nombre: {mascota.nombre}</td>
                                        <td>
                                            <button type="button" className="btn btn-success"
                                                onClick={() => setSubId(mascota.id)}>Actualizar</button>
                                            &nbsp;
                                            <button type="button" className="btn btn-danger"
                                                onClick={() => deleteUser(mascota.id)}>Eliminar</button>
                                        </td>
                                    </tr>
                                </>
                            );
                        })
                    }
                    </tbody>
                </table>
            </div>
            <div className="row">
                <h3>Citas</h3>
                <table className="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Tus Citas</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>{
                        citas.map((mascota) => {
                            return (
                                <>
                                    <tr>
                                        <td>Nombre: {mascota.fecha}</td>
                                        <td>
                                            <button type="button" className="btn btn-success"
                                                onClick={() => deleteteUser(mascota.id)}>Actualizar</button>
                                            &nbsp;
                                            <button type="button" className="btn btn-danger"
                                                onClick={() => deleteUser(mascota.id)}>Eliminar</button>
                                        </td>
                                    </tr>
                                </>
                            );
                        })
                        
                    }
                    </tbody>

                </table>
            </div>
        </div>
    );
}

export default Home;