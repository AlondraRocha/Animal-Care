import React, { useState } from "react"
import firebaseApp from "../credenciales";
import {getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword} from "firebase/auth";

const auth = getAuth(firebaseApp);

export const Logueo = () => {

    const submitDatos = async(e) => {
        e.preventDefault()

        const correo = e.target.email.value;
        const contra = e.target.pass.value;

        if(correo == "brayanpinalopez@gmail.com" && contra == "Polvo#123"){
            await signInWithEmailAndPassword(auth, correo, contra);
        } else {
            console.log("El usuario que ingresaste no tiene permisos")
        }

    }

    return (
        <div className="container">
        <h1>Iniciado sesión</h1>

        <form className="form-control" id="form1" onSubmit={submitDatos}>
        <div className="mb-3">
                    <input type="email" className="form-control" name="email" placeholder="Correo"/>
                </div>
                <div className="mb-3">
                    <input type="password" className="form-control" name="pass" placeholder="Contraseña" />
                </div>
                <button className="btn btn-warning">Enviar</button>
        </form>
        </div>
    )
}