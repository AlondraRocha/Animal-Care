// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCHKF-Gu78CKLna8EHpyOZK2KPv3pwioJI",
  authDomain: "animalcare-ae965.firebaseapp.com",
  projectId: "animalcare-ae965",
  storageBucket: "animalcare-ae965.appspot.com",
  messagingSenderId: "1041891888417",
  appId: "1:1041891888417:web:915ae30f5d1f48ba26c260",
  measurementId: "G-T33CJ4HGVS"
  /*apiKey: "AIzaSyBioOm66fVhmHM068SCuYZXyYJhyPZxJ_Y",
  authDomain: "animalcare1-ca751.firebaseapp.com",
  projectId: "animalcare1-ca751",
  storageBucket: "animalcare1-ca751.appspot.com",
  messagingSenderId: "680452633877",
  appId: "1:680452633877:web:baf63a974ab1ad6686a51c"*/
};

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);

export default firebaseApp;